package com.galaxe.contact.domain;

import java.util.List;

public class AddressResponse {
	List<AddressVO> addressResponse;

	public List<AddressVO> getAddressResponse() {
		return addressResponse;
	}

	public void setAddressResponse(List<AddressVO> addressResponse) {
		this.addressResponse = addressResponse;
	}
	
	
}
