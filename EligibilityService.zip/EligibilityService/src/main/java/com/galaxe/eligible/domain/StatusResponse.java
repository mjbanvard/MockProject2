package com.galaxe.eligible.domain;

import java.util.List;

public class StatusResponse {
	StatusVO statusResponse;
	
	public StatusVO getStatusResponse(){
		return statusResponse;
	}

	public void setStatusResponse(StatusVO statusResponse) {
		this.statusResponse = statusResponse;
		// TODO Auto-generated method stub
		
	}

}
