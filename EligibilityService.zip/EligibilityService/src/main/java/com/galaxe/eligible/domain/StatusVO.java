package com.galaxe.eligible.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class StatusVO {
	

	private String eligStatus;	
	private String benefitGrp;
	

	public String getEligStatus() {
		return eligStatus;
	}

	public void setEligStatus(String eligStatus) {
		this.eligStatus = eligStatus;
	}

	

	public String getBenefitGrp() {
		return benefitGrp;
	}

	public void setBenefitGrp(String benefitGrp) {
		this.benefitGrp = benefitGrp;
	}

}

