package com.galaxe.perscription;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PerscriptionServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
