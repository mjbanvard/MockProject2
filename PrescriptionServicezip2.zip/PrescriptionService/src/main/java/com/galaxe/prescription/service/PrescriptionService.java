package com.galaxe.prescription.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.galaxe.prescription.domain.PrescriptionVO;
import com.galaxe.prescription.domain.Request;
import com.galaxe.prescription.model.PrescriptionBO;

@Service
public interface PrescriptionService {
	
	public String getAgnNumber(String groupId, String carrierId);
	
	public String getAgnString(Request request);
	
//	public String getAgnAsString(String groupId, String carrierId);

}
