package utility;

public class callContactInfoService {
	
//	URL url = new URL("http://localhost:8080");
//	HttpURLConnection con = (HttpURLConnection)url.openConnection();
//	con.setRequestMethod("POST");
	
	
}
